
kivy app number conversion system


Running in a PC install the requiremts in requirements.txt


version 0.1
